docker-compose -f ./artifacts/docker-compose.yaml down

